﻿/*using UnityEngine;
using System.Collections;
using ChilliConnect;

public class ChilliConnectSetup : MonoBehaviour {

    public ChilliConnectSdk chilliConnect = new ChilliConnectSdk("<XuSHCNgn6AHcnqeBoZbKqBlPEgYKmRqI>", false);

    // Use this for initialization
    void Start ()
    {
         public ChilliConnectSdk metrics = chilliConnect.Metrics;
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
*/
